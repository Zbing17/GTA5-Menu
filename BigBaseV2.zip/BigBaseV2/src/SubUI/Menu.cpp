#include "common.hpp"
#include "../natives.hpp"
#include "../script.hpp"
#include "Menu.h"
#include "MenuInterface.h"

//Sorry for my bad English i do my best.
/*Revolution46 is a extension of OriginsBase By DireDan Would be nice if you use this to credit Both me and DireDan This menu base has Numpad , Arrow Keys, Controller support*/
const char* CharKeyboard(const char* windowName = "", int maxInput = 21, const char* defaultText = "") {
	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) 	big::script::get_current()->yield();
	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
}
int NumberKeyboard() {
	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(1, "", "", "", "", "", "", 10);
	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) 	big::script::get_current()->yield();
	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return 0;
	return atof(GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT());
}
//Features.h Define here
//Bool's
bool GodModeBool = false;
bool invisible = false;
bool SuperJump = false;
bool neverwanted = false;
bool rainbowmenu = false; //If you want to have Rainbow colors change false to true bool (rainbowmenu = true;)
//Features.cpp file //I do like offsets more than Natives you can grab offsets from cheat tables with Notepad++ Download here /* https://notepad-plus-plus.org/ */
void Features()
{
	if (GodModeBool)//These offsets are currently working for 1.46 these can change in future updates 
	{
	}
	if (invisible)
	{
		ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false, 0);
	}
	else
	{
		ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true, 0);
	}
	if (SuperJump) //This fucntion is using Natives wich Can be detected in future updates.
	{
		GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
		GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_PED_ID());
	}
	if (neverwanted) //Also using Offsets for 1.46
	{
	}
	if (rainbowmenu)//What this does is generate a random RGB
	{
		if (titleRect.r > 0 && titleRect.b == 0, scroller.r > 0 && scroller.b == 0)
		{
			titleRect.r--;
			titleRect.g++;
			scroller.r--;
			scroller.g++;
		}
		if (titleRect.g > 0 && titleRect.r == 0, scroller.g > 0 && scroller.r == 0)
		{
			titleRect.g--;
			titleRect.b++;
			scroller.g--;
			scroller.b++;
		}
		if (titleRect.b > 0 && titleRect.g == 0, scroller.b > 0 && scroller.g == 0)
		{
			titleRect.r++;
			titleRect.b--;
			scroller.r++;
			scroller.b--;
		}
		(titleRect.r, titleRect.g, titleRect.b);
		(scroller.r, scroller.g, scroller.b);
	}
}

void notifyAboveMap(std::string msg, BOOL blink) {
	UI::SET_TEXT_OUTLINE();
	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(&msg[0u]);
	UI::_DRAW_NOTIFICATION(blink, false);
}

void OriginMenu() {
	//Here you can do thins Before the menu gets to 'mainmenu'
	Features();
	Menu::checkKeys();
	notifyAboveMap("~b~Revolution46 loaded...");
	//Here are you're submenu's defined
	if (Menu::currentMenu("mainmenu")) { 
		Menu::Title("Revolution46");
		Menu::MenuOption("Self Menu", "self_menu");
		Menu::MenuOption("~g~Credits", "credits_menu");
		Menu::MenuOption("Settings Menu", "settings");
	}
	//Self Menu
	if (Menu::currentMenu("self_menu")) {
		Menu::Title("Self Menu");
		Menu::BoolOption("Godmode", &GodModeBool);
		Menu::BoolOption("Invisible", &invisible);
		Menu::BoolOption("SuperJump", &SuperJump);
		Menu::BoolOption("Neverwanted", &neverwanted);
	}
	//Credits
	if (Menu::currentMenu("credits_menu")) {
		Menu::Title("Credits");
		Menu::Option("Developer : ~r~Your Name");
		Menu::Option("Base : ~p~DireDan");
		Menu::Option("Modified : ~r~Kanenanites");
		Menu::Option("Thanks to:");//These are the people who helped with OriginsBase 1.37
		Menu::Option("~b~2much4u");
		Menu::Option("~g~Big_Ghost_Gamer ");
		Menu::Option("~p~Infamous Dev Team");
		Menu::Option("~y~Taran VG");
		Menu::Option("V.0.0");//put your're Version in Here
	}
	//Settings
	if (Menu::currentMenu("settings")) {
		Menu::Title("Settings Menu");

		Menu::MenuOption("Theme", "settings_theme");
		Menu::MenuOption("~g~Credits", "credits_menu");
		if (Menu::Option("~r~Quit GTA")) exit(0);
	}
	if (Menu::currentMenu("settings_theme")) {
		Menu::Title("Theme");

		Menu::BoolOption("Rainbow Menu", &rainbowmenu);
		Menu::MenuOption("Theme Loader", "settings_theme_loader");
		Menu::MenuOption("Title Text", "settings_theme_titletext");
		Menu::MenuOption("Title Rect", "settings_theme_titlerect");
		Menu::MenuOption("Scroller", "settings_theme_scroller");
		Menu::MenuOption("Options Text", "settings_theme_options");
		Menu::MenuOption("Options Rect", "settings_theme_optionsrect");
	}
	if (Menu::currentMenu("settings_theme_loader")) {
		Menu::Title("Theme Loader");//You can load themes in here go to MenuInterface.cpp to change the colors when the menu is on first load.
		if (Menu::Option("Standard")) {
			titleRect = { 30, 144, 255, 255 };
			scroller = { 0, 191, 255, 200 };
		}
		if (Menu::Option("Red Theme")) { //Add more theme's your self
			titleRect = { 255, 0, 0, 255 };
			scroller = { 220, 0, 0, 200 };
		}
	}
	if (Menu::currentMenu("settings_theme_titletext")) {
		Menu::Title("Title Text");

		Menu::IntOption("Red: ", &titleText.r, 0, 255);
		Menu::IntOption("Green: ", &titleText.g, 0, 255);
		Menu::IntOption("Blue: ", &titleText.b, 0, 255);
		Menu::IntOption("Alpha: ", &titleText.a, 0, 255);
	}
	if (Menu::currentMenu("settings_theme_titlerect")) {
		Menu::Title("Title Rect");

		Menu::IntOption("Red: ", &titleRect.r, 0, 255);
		Menu::IntOption("Green: ", &titleRect.g, 0, 255);
		Menu::IntOption("Blue: ", &titleRect.b, 0, 255);
		Menu::IntOption("Alpha: ", &titleRect.a, 0, 255);
	}
	if (Menu::currentMenu("settings_theme_scroller")) {
		Menu::Title("Scroller");

		Menu::IntOption("Red: ", &scroller.r, 0, 255);
		Menu::IntOption("Green: ", &scroller.g, 0, 255);
		Menu::IntOption("Blue: ", &scroller.b, 0, 255);
		Menu::IntOption("Alpha: ", &scroller.a, 0, 255);
	}
	if (Menu::currentMenu("settings_theme_options")) {
		Menu::Title("Options Text");

		Menu::IntOption("Red: ", &options.r, 0, 255);
		Menu::IntOption("Green: ", &options.g, 0, 255);
		Menu::IntOption("Blue: ", &options.b, 0, 255);
		Menu::IntOption("Alpha: ", &options.a, 0, 255);
	}
	if (Menu::currentMenu("settings_theme_optionsrect")) {
		Menu::Title("Options Rect");

		Menu::IntOption("Red: ", &optionsrect.r, 0, 255);
		Menu::IntOption("Green: ", &optionsrect.g, 0, 255);
		Menu::IntOption("Blue: ", &optionsrect.b, 0, 255);
		Menu::IntOption("Alpha: ", &optionsrect.a, 0, 255);
	}

	Menu::endMenu();

}