void OriginMenu();

void notifyAboveMap(std::string msg, BOOL blink = false);