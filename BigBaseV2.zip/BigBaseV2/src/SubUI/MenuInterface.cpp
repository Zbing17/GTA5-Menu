#include "common.hpp"
#include "../natives.hpp"
#include "../script.hpp"
#include "../gta/enums.hpp"
#include "MenuInterface.h"
//Do not chnage anything in here unless you know what you're doing.
float menux = 0.2f;
rgba titleText = { 255, 255, 255, 255 };
rgba titleRect = { 30, 144, 255, 255 };  //Keep titletext and Option text like it is.
rgba scroller = { 0, 191, 255, 200 };     //Mod colors
rgba options = { 255, 255, 255, 255 }; //Currenly color is on modded Blue
rgba optionsrect = { 255, 255, 255, 110 };

int optioncount;
int currentoption;
bool optionpress = false;
bool leftpress = false;
bool rightpress = false;
bool uppress = false;
bool downpress = false;

char* currentmenu[100];
char* actualmenu = "";
int lastoption[100];
int menulevel = 0;
int infocount;
int Delay = GetTickCount();

int Menu::getKeyPressed(int key) {
	return GetAsyncKeyState(key);
}

char* Menu::StringToChar(std::string string) {
	return _strdup(string.c_str());
}

bool Menu::currentMenu(char* menuname) {
	if (menuname == actualmenu) return true;
	else return false;
}

void Menu::changeMenu(char* menuname) {
	currentmenu[menulevel] = actualmenu;
	lastoption[menulevel] = currentoption;
	menulevel++;
	actualmenu = menuname;
	currentoption = 1;
}

void Menu::backMenu() {
	menulevel--;
	actualmenu = currentmenu[menulevel];
	currentoption = lastoption[menulevel];
}

void Menu::drawText(char* text, int font, float x, float y, float scalex, float scaley, rgba rgba, bool center) {
	UI::SET_TEXT_FONT(font);
	UI::SET_TEXT_SCALE(scalex, scaley);
	UI::SET_TEXT_COLOUR(rgba.r, rgba.g, rgba.b, rgba.a);
	UI::SET_TEXT_CENTRE(center);
	UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
	UI::END_TEXT_COMMAND_DISPLAY_TEXT(x, y);
};

void Menu::drawNotification(char* msg) {
	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(msg);
	UI::_DRAW_NOTIFICATION(false , 1);
};

void Menu::drawRect(float x, float y, float width, float height, rgba rgba) {
	GRAPHICS::DRAW_RECT(x, y, width, height, rgba.r, rgba.g, rgba.b, rgba.a);
};

void Menu::drawSprite(char* Streamedtexture, char* textureName, float x, float y, float width, float height, float rotation, rgba rgba)
{
	if (!GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED(Streamedtexture)) GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT(Streamedtexture, false);
	else GRAPHICS::DRAW_SPRITE(Streamedtexture, textureName, x, y, width, height, rotation, rgba.r, rgba.g, rgba.b, rgba.a);
};
void Menu::Title(char* title) {
	optioncount = 0;
	drawText(title, 7, menux, 0.095f, 0.85f, 0.85f, titleText, true);
	drawRect(menux, 0.1175f, 0.23f, 0.085f, titleRect);
};

bool Menu::Option(char* option) {
	optioncount++;

	bool thisOption = false;
	if (currentoption == optioncount) thisOption = true;

	if (currentoption <= 16 && optioncount <= 16)
	{
		drawText(option, 6, menux - 0.1f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, false);
		drawRect(menux, ((optioncount * 0.035f) + 0.1415f), 0.23f, 0.035f, optionsrect);
		if (thisOption) drawRect(menux, ((optioncount * 0.035f) + 0.1415f), 0.23f, 0.035f, scroller);
	}

	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
	{
		drawText(option, 6, menux - 0.1f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, false);
		drawRect(menux, ((optioncount - (currentoption - 16)) * 0.035f + 0.1415f), 0.23f, 0.035f, optionsrect);
		if (thisOption) drawRect(menux, ((optioncount - (currentoption - 16)) * 0.035f + 0.1415f), 0.23f, 0.035f, scroller);
	}

	if (optionpress && currentoption == optioncount) return true;
	else return false;
};

bool Menu::MenuOption(char* option, char* menu) {
	Option(option);

	if (currentoption <= 16 && optioncount <= 16)
		drawText(">>", 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(">>", 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (optionpress && currentoption == optioncount) {
		optionpress = false;
		changeMenu(menu);
		return true;
	}
	else return false;
}

bool Menu::IntOption(char* option, int *var, int min, int max, int step) {
	Option(option);

	if (currentoption <= 16 && optioncount <= 16)
		drawText(StringToChar("<" + std::to_string(*var) + ">"), 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(StringToChar("<" + std::to_string(*var) + ">"), 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (currentoption == optioncount) {
		if (leftpress) {
			if (*var <= min) *var = max;
			else *var -= step;
			leftpress = false;
			return true;
		}
		if (*var < min) *var = max;
		if (rightpress) {
			if (*var >= max) *var = min;
			else *var += step;
			rightpress = false;
			return true;
		}
		if (*var > max) *var = min;
	}

	if (optionpress && currentoption == optioncount)
		return true;
	else return false;
}

bool Menu::FloatOption(char* option, float *var, float min, float max, float step) {
	Option(option);



	char buf[100];
	_snprintf_s(buf, sizeof(buf), "%.2f", *var);

	if (currentoption <= 16 && optioncount <= 16)
		drawText(StringToChar("<" + (std::string)buf + ">"), 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(StringToChar("<" + (std::string)buf + ">"), 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (currentoption == optioncount) {
		if (leftpress) {
			if (*var <= min) *var = max;
			else *var -= step;
			leftpress = false;
			return true;
		}
		if (*var < min) *var = max;

		if (rightpress) {
			if (*var >= max) *var = min;
			else *var += step;
			rightpress = false;
			return true;
		}
		if (*var > max) *var = min;
	}

	if (optionpress && currentoption == optioncount)
		return true;
	else return false;
}

bool Menu::BoolOption(char* option, bool *b00l) {
	Option(option);
	if (currentoption <= 16 && optioncount <= 16)
		drawSprite("commonmenu", *b00l ? "shop_box_tick" : "shop_box_blank",
			menux + 0.068f, (optioncount * 0.035f + 0.141f), 0.03f, 0.05f, 0, options);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawSprite("commonmenu", *b00l ? "shop_box_tick" : "shop_box_blank",
			menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.141f), 0.03f, 0.05f, 0, options);
	if (optionpress && currentoption == optioncount) {
		*b00l ^= 1;
		return true;
	}
	else return false;
}

bool Menu::BoolSpriteOption(char* option, bool b00l, char* category, char* spriteOn, char* spriteOff) {
	Option(option);

	if (currentoption <= 16 && optioncount <= 16)
		drawSprite(category, b00l ? spriteOn : spriteOff,
			menux + 0.068f, (optioncount * 0.035f + 0.141f), 0.03f, 0.05f, 0, options);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawSprite(category, b00l ? spriteOn : spriteOff,
			menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.141f), 0.03f, 0.05f, 0, options);

	if (optionpress && currentoption == optioncount) return true;
	else return false;
}

bool Menu::IntArray(char* option, int display[], int *PlaceHolderInt) {
	Option(option);

	int min = 0;
	int max = sizeof(display) / sizeof(*display);

	if (currentoption == optioncount) {
		if (leftpress) {
			if (*PlaceHolderInt <= min) *PlaceHolderInt = max;
			else PlaceHolderInt -= 1;
			leftpress = false;
			return true;
		}
		if (*PlaceHolderInt < min) *PlaceHolderInt = max;
		if (rightpress) {
			if (*PlaceHolderInt >= max) *PlaceHolderInt = min;
			else *PlaceHolderInt += 1;
			rightpress = false;
			return true;
		}
		if (*PlaceHolderInt > max) *PlaceHolderInt = min;
	}
	if (currentoption <= 16 && optioncount <= 16)
		drawText(StringToChar("<" + std::to_string(display[*PlaceHolderInt]) + ">"), 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(StringToChar("<" + std::to_string(display[*PlaceHolderInt]) + ">"), 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (optionpress && currentoption == optioncount)
		return true;
	else return false;
}

bool Menu::FloatArray(char* option, float display[], int *PlaceHolderInt) {
	Option(option);

	int min = 0;
	int max = sizeof(display) / sizeof(*display);

	if (currentoption == optioncount) {
		if (leftpress) {
			if (*PlaceHolderInt <= min) *PlaceHolderInt = max;
			else *PlaceHolderInt -= 1;
			leftpress = false;
			return true;
		}
		if (*PlaceHolderInt < min) *PlaceHolderInt = max;
		if (rightpress) {
			if (*PlaceHolderInt >= max) *PlaceHolderInt = min;
			else *PlaceHolderInt += 1;
			rightpress = false;
			return true;
		}
		if (*PlaceHolderInt > max) *PlaceHolderInt = min;
	}

	char buf[30];
	_snprintf_s(buf, sizeof(buf), "%.2f", display[*PlaceHolderInt]);

	if (currentoption <= 16 && optioncount <= 16)
		drawText(StringToChar("<" + (std::string)buf + ">"), 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(StringToChar("<" + (std::string)buf + ">"), 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (optionpress && currentoption == optioncount)
		return true;
	else return false;
}

bool Menu::CharArray(char* option, char* display[], int *PlaceHolderInt) {
	Option(option);

	int min = 0;
	int max = sizeof(display) / sizeof(*display) + 1;

	if (currentoption == optioncount) {
		if (leftpress) {
			if (*PlaceHolderInt <= min) *PlaceHolderInt = max;
			else *PlaceHolderInt -= 1;
			leftpress = false;
		}
		if (*PlaceHolderInt < min) *PlaceHolderInt = max;
		if (rightpress) {
			if (*PlaceHolderInt >= max) *PlaceHolderInt = min;
			else *PlaceHolderInt += 1;
			rightpress = false;
		}
		if (*PlaceHolderInt > max) *PlaceHolderInt = min;
	}
	if (currentoption <= 16 && optioncount <= 16)
		drawText(StringToChar("<" + (std::string)display[*PlaceHolderInt] + ">"), 6, menux + 0.068f, (optioncount * 0.035f + 0.125f), 0.5f, 0.5f, options, true);
	else if ((optioncount > (currentoption - 16)) && optioncount <= currentoption)
		drawText(StringToChar("<" + (std::string)display[*PlaceHolderInt] + ">"), 6, menux + 0.068f, ((optioncount - (currentoption - 16)) * 0.035f + 0.125f), 0.5f, 0.5f, options, true);

	if (optionpress && currentoption == optioncount)
		return true;
	else return false;
}

void Menu::TeleportOption(char* option, float x, float y, float z) {
	Option(option);

	if (currentoption == optioncount && optionpress) {
		Entity handle = PLAYER::PLAYER_PED_ID();
		if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false)) handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID());
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, x, y, z, false, false, false);
	}
}
void Menu::endMenu() {
	if (menulevel > 0)
	{
		if (optioncount > 16)
		{
			drawText(StringToChar(std::to_string(currentoption) + "/" + std::to_string(optioncount)),
				6, menux - 0.1f, (17 * 0.035f + 0.125f), 0.5f, 0.5f, titleText, false);
			drawRect(menux, (17 * 0.035f + 0.1415f), 0.23f, 0.035f, titleRect);

			if (currentoption == 1) {
				drawSprite("commonmenu", "arrowright", menux, ((16 + 1) * 0.035f + 0.145f), 0.02f, 0.02f, 90, titleText);
			}
			else if (currentoption == optioncount) {
				drawSprite("commonmenu", "arrowright", menux, ((16 + 1) * 0.035f + 0.145f), 0.02f, 0.02f, 270, titleText);
			}
			else {
				drawSprite("commonmenu", "arrowright", menux, ((16 + 1) * 0.035f + 0.14f), 0.02f, 0.02f, 270, titleText);
				drawSprite("commonmenu", "arrowright", menux, ((16 + 1) * 0.035f + 0.15f), 0.02f, 0.02f, 90, titleText);
			}
		}
		else
		{
			drawText(StringToChar(std::to_string(currentoption) + "/" + std::to_string(optioncount)),
				6, menux - 0.1f, ((optioncount + 1) * 0.035f + 0.125f), 0.5f, 0.5f, titleText, false);
			drawRect(menux, ((optioncount + 1) * 0.035f + 0.1415f), 0.23f, 0.035f, titleRect);

			if (currentoption == 1 && optioncount > 1) {
				drawSprite("commonmenu", "arrowright", menux, ((optioncount + 1) * 0.035f + 0.145f), 0.02f, 0.02f, 90, titleText);
			}
			else if (currentoption == optioncount && optioncount > 1) {
				drawSprite("commonmenu", "arrowright", menux, ((optioncount + 1) * 0.035f + 0.145f), 0.02f, 0.02f, 270, titleText);
			}
			else if (optioncount > 1) {
				drawSprite("commonmenu", "arrowright", menux, ((optioncount + 1) * 0.035f + 0.14f), 0.02f, 0.02f, 270, titleText);
				drawSprite("commonmenu", "arrowright", menux, ((optioncount + 1) * 0.035f + 0.15f), 0.02f, 0.02f, 90, titleText);
			}
		}


		UI::HIDE_HELP_TEXT_THIS_FRAME();
		CAM::SET_CINEMATIC_BUTTON_ACTIVE(0);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(10);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(6);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(7);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(9);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(8);

		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlNextCamera, true);

		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlPhone, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlVehicleCinCam, true);

		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlSelectCharacterMichael, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlSelectCharacterFranklin, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlSelectCharacterTrevor, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlSelectCharacterMultiplayer, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlCharacterWheel, true);

		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlMeleeAttackLight, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlMeleeAttackHeavy, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlMeleeAttackAlternate, true);

		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlMultiplayerInfo, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, ControlMapPointOfInterest, true);

		if (currentoption > optioncount) currentoption = optioncount;
		if (currentoption < 1) currentoption = 1;
	}
}

void Menu::checkKeys() {
	optionpress = false;
	if (GetTickCount() - Delay > 150) {
		if (getKeyPressed(VK_MULTIPLY) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendLb) &&
			CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendRb)) {
			if (menulevel == 0) changeMenu("mainmenu");
			else if (menulevel == 1) backMenu();
			Delay = GetTickCount();
		}
		if (getKeyPressed(VK_NUMPAD0) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendCancel)) {
			if (menulevel > 0)
				backMenu();
			Delay = GetTickCount();
		}
		if (getKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
			optionpress = true;
			Delay = GetTickCount();
		}
		if (getKeyPressed(VK_NUMPAD2) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendDown)) {
			if (currentoption < optioncount)
				currentoption++;
			else
				currentoption = 1;
			Delay = GetTickCount();
			downpress = true;
		}
		if (getKeyPressed(VK_NUMPAD8) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendUp)) {
			if (currentoption > 1)
				currentoption--;
			else
				currentoption = optioncount;
			Delay = GetTickCount();
			uppress = true;
		}
		if (getKeyPressed(VK_NUMPAD4) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneLeft)) {
			leftpress = true;
			Delay = GetTickCount();
		}
		if (getKeyPressed(VK_NUMPAD6) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight)) {
			rightpress = true;
			Delay = GetTickCount();
		}
	}
}