#pragma once
#include "common.hpp"

namespace big::features
{
	void run_tick();
	void script_func();
}
